﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;


public partial class recruiter_newpw : System.Web.UI.Page
{
    SqlDataAdapter adp = null;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string query = "select que_id,ansr,username from Company where company_id=6";
        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.fill(ds);

        string ansr = null;
        string a = null;
        a = ds.Table[0].row[0]["ansr"].tostring();
        ansr = TextBox1.Text;

        if (a == ansr)
        {
            Label23.Text = ds.Tables[0].Rows[0]["username"].ToString();
            TextBox2.Enabled = true;
            TextBox3.Enabled = true;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == TextBox3.Text)
        {
            Label48.Visible = false;
            string query = "update Loginset password '" + TextBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

        }
        else {
            Label48.Visible = true;
            Label48.Text = "Password did not matched";
        }
    }
}