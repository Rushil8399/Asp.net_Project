﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

public partial class post_job : System.Web.UI.Page
{
    SqlDataAdapter adp = null;
    public void category()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string query = "select * from Category";
        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);

        DropDownList1.DataSource = ds.Tables[0];
        DropDownList1.DataTextField = "category_name";
        DropDownList1.DataValueField = "category_id";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, new ListItem("select", "0"));

        con.Close();
    }
    public void area()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string query = "select * from Area where Area.category_id=" + DropDownList1.SelectedValue;
        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);

        DropDownList2.DataSource = ds.Tables[0];
        DropDownList2.DataTextField = "area_name";
        DropDownList2.DataValueField = "area_id";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("select", "0"));

        con.Close();
    }
    public void country()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string query = "select * from Country";
        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);

        DropDownList6.DataSource = ds.Tables[0];
        DropDownList6.DataTextField = "country_name";
        DropDownList6.DataValueField = "country_id";
        DropDownList6.DataBind();
        DropDownList6.Items.Insert(0, new ListItem("select", "0"));

        con.Close();

    }
    public void state()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string query = "select * from State where State.country_id=" + DropDownList6.SelectedValue;
        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);

        DropDownList7.DataSource = ds.Tables[0];
        DropDownList7.DataTextField = "state_name";
        DropDownList7.DataValueField = "state_id";
        DropDownList7.DataBind();
        DropDownList7.Items.Insert(0, new ListItem("select", "0"));

        con.Close();

    }
    public void city()
    {
        
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();

        SqlDataAdapter adp = null;
        string query = "select * from City where City.state_id=" + DropDownList7.SelectedValue;

        adp = new SqlDataAdapter(query, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList8.DataSource = ds.Tables[0];
        DropDownList8.DataTextField = "city_name";
        DropDownList8.DataValueField = "city_id";
        DropDownList8.DataBind();
        DropDownList8.Items.Insert(0, new ListItem("select", "0"));
        con.Close();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            country();
            DropDownList7.Items.Insert(0, new ListItem("select", "0"));

            DropDownList8.Items.Insert(0, new ListItem("select", "0"));

            category();
            DropDownList2.Items.Insert(0, new ListItem("select", "0"));
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
        con.Open();
        string exprnc = null;
        exprnc = DropDownList4.Text + "Years and" + DropDownList5.Text + "Months";
        string qry = "insert into job_post(company_id,job_title,area_id,city_id,post,no_vacancy,start_date,end_date,expr_req,skills_req,edu_req,basic_req,salary_min,salary_max) values ('1','" + TextBox1.Text + "','" + DropDownList1.SelectedItem + "','2','" + TextBox2.Text + "','" + DropDownList12.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + exprnc + "','" + TextBox3.Text + "','" + DropDownList11.SelectedItem + "','" + TextBox4.Text + "','" + DropDownList9.SelectedItem + "','" + DropDownList10.SelectedItem + "')";
        SqlCommand cmd = new SqlCommand(qry,con);

       int i =  cmd.ExecuteNonQuery();
       if (i > 0)
       {
           Response.Write("<script> alert('Record saved Successfuly')</script>");
       }
       con.Close();
    
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        area();
    }
    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
    {
        state();
    }
    protected void DropDownList7_SelectedIndexChanged(object sender, EventArgs e)
    {
        city();
    }
}